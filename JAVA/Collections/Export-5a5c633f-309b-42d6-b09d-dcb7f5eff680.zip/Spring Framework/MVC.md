# MVC

URI를 분석해서 적절한 컨트롤러를 찾는 작업

Controller에 필요한 메소드를 호출하는 작업

Controller의 결과 데이터를 View로 전달하는 작업

적절한 View를 찾는 작업